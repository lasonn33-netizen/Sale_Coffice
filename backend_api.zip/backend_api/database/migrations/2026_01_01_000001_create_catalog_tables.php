<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('categories', function (Blueprint $table) { $table->id(); $table->string('name', 100)->unique(); $table->text('description')->nullable(); $table->timestamps(); });
        Schema::create('products', function (Blueprint $table) { $table->id(); $table->foreignId('category_id')->constrained()->restrictOnDelete(); $table->string('name', 150); $table->text('description')->nullable(); $table->decimal('price', 10, 2); $table->text('image_url')->nullable(); $table->boolean('is_available')->default(true); $table->timestamps(); });
    }
    public function down(): void { Schema::dropIfExists('products'); Schema::dropIfExists('categories'); }
};
